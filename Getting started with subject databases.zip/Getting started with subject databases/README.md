# 🐞 Gulp starter template for CodyFrame

To start your web project, run the following two commands:
1. Install the node modules.

```
npm install
```

2. Launch your project on a development server.

```
npm run gulp watch
```

[Documentation on codyhouse.co →](https://codyhouse.co/ds/docs/framework#new-gulp-project)