// File#: _1_confetti-button
// Usage: codyhouse.co/license
(function () {
  var ConfettiBtn = function (element) {
    this.element = element;
    this.btn = this.element.getElementsByClassName("js-confetti-btn__btn");
    this.icon = this.element.getElementsByClassName("js-confetti-btn__icon");
    this.animating = false;
    this.animationClass = "confetti-btn--animate";
    this.positionVariables = "--conf-btn-click-";
    initConfettiBtn(this);
  };

  function initConfettiBtn(element) {
    if (element.btn.length < 1 || element.icon.length < 1) return;
    element.btn[0].addEventListener("click", function (event) {
      if (element.animating) return;
      element.animating = true;
      setAnimationPosition(element, event);
      Util.addClass(element.element, element.animationClass);
      resetAnimation(element);
    });
  }

  function setAnimationPosition(element, event) {
    // change icon position based on click position

    var btnBoundingRect = element.btn[0].getBoundingClientRect();
    document.documentElement.style.setProperty(
      element.positionVariables + "x",
      event.clientX - btnBoundingRect.left + "px"
    );
    document.documentElement.style.setProperty(
      element.positionVariables + "y",
      event.clientY - btnBoundingRect.top + "px"
    );
  }

  function resetAnimation(element) {
    // reset the button at the end of the icon animation

    element.icon[0].addEventListener("animationend", function cb() {
      element.icon[0].removeEventListener("animationend", cb);
      Util.removeClass(element.element, element.animationClass);
      element.animating = false;
    });
  }

  var confettiBtn = document.getElementsByClassName("js-confetti-btn");
  if (confettiBtn.length > 0) {
    for (var i = 0; i < confettiBtn.length; i++) {
      (function (i) {
        new ConfettiBtn(confettiBtn[i]);
      })(i);
    }
  }
})();
